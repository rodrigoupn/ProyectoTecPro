package sim_banco.banco_interfaz;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;

public class CajeroBCPGUI extends JFrame {
    private Cliente clienteActual;
    private Cajero cajero = new Cajero();
    private JTextArea outputArea = new JTextArea(5, 30);
    public static Cliente[] clientesGlobales;

    public CajeroBCPGUI(Cliente cliente) {
        this.clienteActual = cliente;

        setTitle("Cajero BCP - Bienvenido, " + cliente.getNombre());
        setSize(450, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        Color azulBCP = new Color(0, 51, 153);
        Color naranjaBCP = new Color(255, 102, 0);

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(Color.WHITE);

        // Logo
        JLabel logo = new JLabel();
        try {
            ImageIcon icon = new ImageIcon("resources/logo_bcp.png");
            Image img = icon.getImage().getScaledInstance(200, 60, Image.SCALE_SMOOTH);
            logo.setIcon(new ImageIcon(img));
        } catch (Exception e) {
            logo.setText("BCP");
        }

        JPanel topPanel = new JPanel();
        topPanel.setBackground(Color.WHITE);
        topPanel.add(logo);
        panel.add(topPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridLayout(5, 1, 10, 10));
        centerPanel.setBackground(azulBCP);

        JButton consultarBtn = new JButton("Consultar Saldo");
        JButton depositarBtn = new JButton("Depositar");
        JButton retirarBtn = new JButton("Retirar");
        JButton transferirBtn = new JButton("Transferir");
        JButton salirBtn = new JButton("Salir");

        outputArea.setEditable(false);
        outputArea.setFont(new Font("Arial", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(outputArea);

        // Acción: consultar saldo
        consultarBtn.addActionListener(e -> {
            cajero.consultarSaldo(clienteActual, outputArea);
            Cliente.registrarOperacion(clienteActual, "Consulta de Saldo", 0);
            clienteActual.guardarOperacion("Consulta de Saldo", 0, "");
            Recibo.preguntarYGenerar(clienteActual, "Consulta de Saldo", 0);
        });

        // Acción: depositar
        depositarBtn.addActionListener(e -> {
            String input = JOptionPane.showInputDialog(this, "Monto a depositar:");
            if (input != null && !input.isEmpty()) {
                try {
                    double monto = Double.parseDouble(input);
                    cajero.depositar(clienteActual, monto, outputArea);
                    Cliente.registrarOperacion(clienteActual, "Depósito", monto);
                    clienteActual.guardarOperacion("Depósito", monto, "");
                    guardarClientesEnArchivo("clientes.txt", clientesGlobales);
                    String nro = Recibo.preguntarYGenerar(clienteActual, "Depósito", monto);
                    if (!nro.isEmpty()) {
                        JOptionPane.showMessageDialog(this, "Depósito exitoso.\nN° de operación: " + nro);
                    }
                } catch (NumberFormatException ex) {
                    outputArea.setText("Monto inválido.");
                }
            }
        });

        // Acción: retirar
        retirarBtn.addActionListener(e -> {
            String pin = JOptionPane.showInputDialog(this, "Ingrese su PIN de 4 dígitos:");
            if (!clienteActual.getPin().equals(pin)) {
                outputArea.setText("PIN incorrecto. Retiro cancelado.");
                return;
            }

            String input = JOptionPane.showInputDialog(this, "Monto a retirar:");
            if (input != null && !input.isEmpty()) {
                try {
                    double monto = Double.parseDouble(input);
                    cajero.retirar(clienteActual, monto, outputArea);
                    Cliente.registrarOperacion(clienteActual, "Retiro", monto);
                    clienteActual.guardarOperacion("Retiro", monto, "");
                    guardarClientesEnArchivo("clientes.txt", clientesGlobales);
                    Recibo.preguntarYGenerar(clienteActual, "Retiro", monto);
                } catch (NumberFormatException ex) {
                    outputArea.setText("Monto inválido.");
                }
            }
        });

        // Acción: transferir
        transferirBtn.addActionListener(e -> {
            String[] bancos = {"BCP", "BBVA", "Scotiabank"};
            String banco = (String) JOptionPane.showInputDialog(this, "Elija el banco destino:", "Transferencia", JOptionPane.PLAIN_MESSAGE, null, bancos, "BCP");

            if (banco == null) return;

            String cuentaDestino = banco.equals("BCP")
                    ? JOptionPane.showInputDialog(this, "Ingrese el N° de cuenta BCP:")
                    : JOptionPane.showInputDialog(this, "Ingrese el CCI del otro banco:");

            if (cuentaDestino == null || cuentaDestino.isEmpty()) return;

            String montoStr = JOptionPane.showInputDialog(this, "Ingrese el monto a transferir:");
            if (montoStr == null || montoStr.isEmpty()) return;

            try {
                double monto = Double.parseDouble(montoStr);

                if (clienteActual.getSaldo() < monto) {
                    outputArea.setText("Saldo insuficiente.");
                    return;
                }

                if (banco.equals("BCP")) {
                    boolean encontrado = false;
                    for (Cliente c : clientesGlobales) {
                        if (c.getDni().equals(cuentaDestino)) {
                            clienteActual.retirar(monto);
                            c.depositar(monto);
                            outputArea.setText("Transferencia BCP exitosa a " + c.getNombre() + ". Nuevo saldo: S/ " + clienteActual.getSaldo());
                            Cliente.registrarOperacion(clienteActual, "Transferencia a BCP", monto);
                            clienteActual.guardarOperacion("Transferencia a BCP", monto, cuentaDestino);
                            guardarClientesEnArchivo("clientes.txt", clientesGlobales);
                            encontrado = true;
                            break;
                        }
                    }
                    if (!encontrado) outputArea.setText("Cuenta BCP no encontrada.");
                } else {
                    clienteActual.retirar(monto);
                    clienteActual.guardarOperacion("Transferencia a " + banco, monto, cuentaDestino);
                    Cliente.registrarOperacion(clienteActual, "Transferencia a " + banco, monto);
                    outputArea.setText("Transferencia a " + banco + " exitosa. Nuevo saldo: S/ " + clienteActual.getSaldo());
                    guardarClientesEnArchivo("clientes.txt", clientesGlobales);
                }
            } catch (NumberFormatException ex) {
                outputArea.setText("Monto inválido.");
            }
        });

        // Acción: salir
        salirBtn.addActionListener(e -> {
            clienteActual.guardarDatos();
            JOptionPane.showMessageDialog(this, "Gracias por usar el BCP.");
            dispose();
            main(null); // Volver al login
        });

        // Estilo
        for (JButton btn : new JButton[]{consultarBtn, depositarBtn, retirarBtn, transferirBtn, salirBtn}) {
            btn.setBackground(naranjaBCP);
            btn.setForeground(Color.WHITE);
            btn.setFont(new Font("Arial", Font.BOLD, 18));
            btn.setPreferredSize(new Dimension(200, 40));
        }

        centerPanel.add(consultarBtn);
        centerPanel.add(depositarBtn);
        centerPanel.add(retirarBtn);
        centerPanel.add(transferirBtn);
        centerPanel.add(salirBtn);
        panel.add(centerPanel, BorderLayout.CENTER);
        panel.add(scrollPane, BorderLayout.SOUTH);

        add(panel);
        setVisible(true);
    }

    // Leer clientes desde archivo CSV
    public static Cliente[] leerClientesDesdeArchivo(String archivo) {
        ArrayList<Cliente> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 6) {
                    String nombre = partes[0];
                    String dni = partes[1];
                    String pin = partes[2];
                    double saldo = Double.parseDouble(partes[3]);
                    String cuenta = partes[4];
                    String cci = partes[5];
                    lista.add(new Cliente(nombre, dni, pin, saldo, cuenta, cci));
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "No se pudo leer el archivo de clientes.");
        }
        return lista.toArray(new Cliente[0]);
    }

    // Guardar clientes en archivo CSV
    public static void guardarClientesEnArchivo(String archivo, Cliente[] clientes) {
        try (FileWriter writer = new FileWriter(archivo)) {
            for (Cliente c : clientes) {
                writer.write(
                        c.getNombre() + "," +
                                c.getDni() + "," +
                                c.getPin() + "," +
                                c.getSaldo() + "," +
                                c.getNumeroCuenta() + "," +
                                c.getCci() + "\n"
                );
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "No se pudo guardar el archivo de clientes.");
        }
    }

    // Método principal (login)
    public static void main(String[] args) {
        clientesGlobales = leerClientesDesdeArchivo("clientes.txt");

        int intentos = 0;
        Cliente encontrado = null;

        while (intentos < 3 && encontrado == null) {
            String dni = JOptionPane.showInputDialog(null, "Ingrese su DNI (8 dígitos):");
            if (dni == null) break;

            Cliente cargado = Cliente.cargarDesdeArchivo(dni);

            if (cargado != null) {
                encontrado = cargado;
            } else {
                for (Cliente c : clientesGlobales) {
                    if (c.getDni().equals(dni)) {
                        encontrado = c;
                        break;
                    }
                }
            }

            if (encontrado == null) {
                JOptionPane.showMessageDialog(null, "DNI no encontrado. Intente nuevamente.");
                intentos++;
            }
        }

        if (encontrado != null) {
            new CajeroBCPGUI(encontrado);
        } else {
            JOptionPane.showMessageDialog(null, "Demasiados intentos fallidos. Acceso denegado.");
        }
    }
}
