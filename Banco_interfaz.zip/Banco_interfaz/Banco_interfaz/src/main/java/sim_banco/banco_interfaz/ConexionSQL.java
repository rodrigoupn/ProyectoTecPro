package sim_banco.banco_interfaz;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionSQL {
    public static Connection conectar() {
        Connection con = null;
        try {
            // Cargar el driver JDBC
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            // URL de conexión
            String url = "jdbc:sqlserver://localhost:1433;databaseName=CajeroBCP;encrypt=true;trustServerCertificate=true";

            // Usuario y contraseña (reemplaza con los tuyos)
            String usuario = "sa";
            String contraseña = "2303";

            // Intentar la conexión
            con = DriverManager.getConnection(url, usuario, contraseña);
            System.out.println("🟢 Conexión exitosa.");
        } catch (Exception e) {
            System.out.println("❌ Error al conectar: " + e.getMessage());
        }
        return con;
    }  
}
