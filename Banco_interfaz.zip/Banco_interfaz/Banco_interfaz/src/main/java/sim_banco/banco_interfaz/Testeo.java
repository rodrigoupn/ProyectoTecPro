package sim_banco.banco_interfaz;

import java.sql.Connection;

public class Testeo {
    public static void main(String[] args) {
        Connection con = ConexionSQL.conectar();
        if (con != null) {
            System.out.println("✅ Todo bien, Java se conectó a SQL Server");
        } else {
            System.out.println("❌ No se pudo conectar");
        }
    }
}

