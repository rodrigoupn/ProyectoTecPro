package sim_banco.banco_interfaz;

import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Cliente {
    private String nombre;
    private String dni;
    private String pin;
    private String numeroCuenta;
    private String cci;
    private double saldo;

    public Cliente(String nombre, String dni, String pin, double saldo, String numeroCuenta, String cci) {
        this.nombre = nombre;
        this.dni = dni;
        this.pin = pin;
        this.saldo = saldo;
        this.numeroCuenta = numeroCuenta;
        this.cci = cci;
    }

    public String getNombre() { return nombre; }
    public String getDni() { return dni; }
    public String getPin() { return pin; }
    public double getSaldo() { return saldo; }
    public String getNumeroCuenta() { return numeroCuenta; }
    public String getCci() { return cci; }

    public void depositar(double monto) {
        saldo += monto;
    }

    public boolean retirar(double monto) {
        if (monto <= saldo) {
            saldo -= monto;
            return true;
        }
        return false;
    }

    public void guardarOperacion(String tipo, double monto, String destino) {
        try {
            String fileName = "operaciones_" + dni + ".txt";
            FileWriter writer = new FileWriter(fileName, true);
            String tiempo = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(LocalDateTime.now());

            writer.write("[" + tiempo + "] " + tipo);
            if (!tipo.equals("Consulta de Saldo")) writer.write(" - Monto: S/ " + monto);
            if (destino != null && !destino.isEmpty()) writer.write(" - Destino: " + destino);
            writer.write(" - Saldo final: S/ " + saldo + "\n");
            writer.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar operación.");
        }
    }

    public void guardarDatos() {
        try {
            FileWriter writer = new FileWriter("cliente_" + dni + ".txt");
            writer.write("Nombre: " + nombre + "\nDNI: " + dni + "\nPIN: " + pin + "\nNúmero de Cuenta: " + numeroCuenta + "\nCCI: " + cci + "\nSaldo: S/ " + saldo + "\n");
            writer.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar los datos del cliente.");
        }
    }

    public static Cliente cargarDesdeArchivo(String dni) {
        try {
            List<String> lineas = Files.readAllLines(Paths.get("cliente_" + dni + ".txt"));
            String nombre = lineas.get(0).split(": ")[1];
            String pin = lineas.get(2).split(": ")[1];
            String numeroCuenta = lineas.get(3).split(": ")[1];
            String cci = lineas.get(4).split(": ")[1];
            double saldo = Double.parseDouble(lineas.get(5).split(": ")[1].replace("S/ ", ""));
            return new Cliente(nombre, dni, pin, saldo, numeroCuenta, cci);
        } catch (IOException e) {
            return null;
        }
    }

    public static void registrarOperacion(Cliente cliente, String tipo, double monto) {
        try {
            FileWriter writer = new FileWriter("operaciones_" + cliente.getDni() + ".txt", true);
            String tiempo = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(LocalDateTime.now());
            writer.write("[" + tiempo + "] " + tipo);
            if (!tipo.equalsIgnoreCase("Consulta de Saldo")) writer.write(" - Monto: S/ " + monto);
            writer.write(" - Saldo final: S/ " + cliente.getSaldo() + "\n");
            writer.close();
        } catch (IOException e) {
            System.out.println("Error al registrar operación: " + e.getMessage());
        }
    }
}
