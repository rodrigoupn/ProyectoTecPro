package sim_banco.banco_interfaz;

import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class Recibo {
    public static String preguntarYGenerar(Cliente cliente, String tipoOperacion, double monto) {
        int opcion = JOptionPane.showConfirmDialog(null, "¿Desea generar un recibo?", "Recibo", JOptionPane.YES_NO_OPTION);
        String numeroOperacion = "";

        if (opcion == JOptionPane.YES_OPTION) {
            try {
                String fileName = "recibo_" + cliente.getDni() + "_" + System.currentTimeMillis() + ".txt";
                FileWriter writer = new FileWriter(fileName);
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

                numeroOperacion = String.valueOf(1000000000L + new Random().nextLong(9000000000L));
                writer.write("----- BCP Cajero Virtual -----\n");
                writer.write("Fecha: " + dtf.format(LocalDateTime.now()) + "\n");
                writer.write("Cliente: " + cliente.getNombre() + "\n");
                writer.write("DNI: " + cliente.getDni() + "\n");
                writer.write("Operación: " + tipoOperacion + "\n");
                writer.write("N° de Operación: " + numeroOperacion + "\n");

                if (!tipoOperacion.equals("Consulta de Saldo")) {
                    writer.write("Monto: S/ " + monto + "\n");
                }

                writer.write("Saldo actual: S/ " + cliente.getSaldo() + "\n");
                writer.write("-----------------------------\n");
                writer.close();

                Runtime.getRuntime().exec("notepad " + fileName);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error al generar o abrir el recibo.");
            }
        }

        return numeroOperacion;
    }

    static void preguntarYGenerar(Cliente clienteActual, String consulta_de_Saldo, int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
