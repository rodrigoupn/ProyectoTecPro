package sim_banco.banco_interfaz;

import javax.swing.*;

public class Cajero implements OperacionesBancarias {

    public void consultarSaldo(Cliente cliente, JTextArea area) {
        area.setText("Saldo actual: S/ " + cliente.getSaldo());
    }

    public void depositar(Cliente cliente, double monto, JTextArea area) {
        cliente.depositar(monto);
        area.setText("Depósito exitoso. Nuevo saldo: S/ " + cliente.getSaldo());
    }

    public void retirar(Cliente cliente, double monto, JTextArea area) {
        if (cliente.retirar(monto)) {
            area.setText("Retiro exitoso. Nuevo saldo: S/ " + cliente.getSaldo());
        } else {
            area.setText("Fondos insuficientes.");
        }
    }
}
