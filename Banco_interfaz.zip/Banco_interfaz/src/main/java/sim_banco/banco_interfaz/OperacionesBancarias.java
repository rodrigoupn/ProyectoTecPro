package sim_banco.banco_interfaz;

import javax.swing.*;

public interface OperacionesBancarias {
    void consultarSaldo(Cliente cliente, JTextArea area);
    void depositar(Cliente cliente, double monto, JTextArea area);
    void retirar(Cliente cliente, double monto, JTextArea area);
}

